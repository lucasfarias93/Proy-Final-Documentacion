package com.example.lfarias.actasdigitales.Entities;

/**
 * Created by lfarias on 8/28/17.
 */

public class ReclamoErrorActaEstado {
    private int id;
    private String nombreReclamoErrorActaEstado;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombreReclamoErrorActaEstado() {
        return nombreReclamoErrorActaEstado;
    }

    public void setNombreReclamoErrorActaEstado(String nombreReclamoErrorActaEstado) {
        this.nombreReclamoErrorActaEstado = nombreReclamoErrorActaEstado;
    }
}
