package com.example.lfarias.actasdigitales.Entities;

/**
 * Created by lfarias on 8/28/17.
 */

public class RolesRecursos {
    private int id;
    private int roles_id;
    private int recursos_id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getRoles_id() {
        return roles_id;
    }

    public void setRoles_id(int roles_id) {
        this.roles_id = roles_id;
    }

    public int getRecursos_id() {
        return recursos_id;
    }

    public void setRecursos_id(int recursos_id) {
        this.recursos_id = recursos_id;
    }
}
