package com.example.lfarias.actasdigitales.Entities;

/**
 * Created by lfarias on 8/28/17.
 */

public class OperacionRol {
    private int id;
    private int idRol;
    private int idOpetacion;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdRol() {
        return idRol;
    }

    public void setIdRol(int idRol) {
        this.idRol = idRol;
    }

    public int getIdOpetacion() {
        return idOpetacion;
    }

    public void setIdOpetacion(int idOpetacion) {
        this.idOpetacion = idOpetacion;
    }
}
